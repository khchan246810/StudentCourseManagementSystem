namespace StudentCourseManagementSystem
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            Data.Database.Initialize();

            Application.Run(new MainForm());
        }
    }
}