namespace StudentCourseManagementSystem.Models
{
    public class Course
    {
        public int Id { get; set; }

        public string CourseCode { get; set; } = "";

        public string CourseName { get; set; } = "";

        public int CreditHours { get; set; }
    }
}