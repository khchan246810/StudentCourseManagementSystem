namespace StudentCourseManagementSystem.Models
{
    public class Student
    {
        public int Id { get; set; }

        public string StudentId { get; set; } = "";

        public string Name { get; set; } = "";

        public string Email { get; set; } = "";

        public string Programme { get; set; } = "";

        public int Year { get; set; }
    }
}