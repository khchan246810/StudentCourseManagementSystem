using Microsoft.Data.Sqlite;

namespace StudentCourseManagementSystem
{
    public class MainForm : Form
    {
        // ==============================
        // STUDENT CONTROLS
        // ==============================

        TextBox txtStudentId = new TextBox();
        TextBox txtStudentName = new TextBox();
        TextBox txtStudentEmail = new TextBox();
        TextBox txtProgramme = new TextBox();

        NumericUpDown numYear = new NumericUpDown();

        DataGridView studentGrid = new DataGridView();

        // ==============================
        // COURSE CONTROLS
        // ==============================

        TextBox txtCourseCode = new TextBox();
        TextBox txtCourseName = new TextBox();

        NumericUpDown numCreditHours = new NumericUpDown();

        DataGridView courseGrid = new DataGridView();

        int selectedStudentId = -1;
        int selectedCourseId = -1;

        public MainForm()
        {
            Text = "Student Course Management System";
            Width = 1100;
            Height = 700;
            StartPosition = FormStartPosition.CenterScreen;

            CreateInterface();

            LoadStudents();
            LoadCourses();
        }

        // =========================================================
        // MAIN INTERFACE
        // =========================================================

        private void CreateInterface()
        {
            TabControl tabs = new TabControl();

            tabs.Dock = DockStyle.Fill;

            TabPage studentTab = new TabPage("Student Management");
            TabPage courseTab = new TabPage("Course Management");

            CreateStudentInterface(studentTab);
            CreateCourseInterface(courseTab);

            tabs.TabPages.Add(studentTab);
            tabs.TabPages.Add(courseTab);

            Controls.Add(tabs);
        }

        // =========================================================
        // STUDENT INTERFACE
        // =========================================================

        private void CreateStudentInterface(TabPage tab)
        {
            Label lblStudentId = new Label();
            lblStudentId.Text = "Student ID:";
            lblStudentId.Location = new Point(30, 30);
            lblStudentId.AutoSize = true;

            txtStudentId.Location = new Point(150, 27);
            txtStudentId.Width = 250;

            Label lblName = new Label();
            lblName.Text = "Name:";
            lblName.Location = new Point(30, 70);
            lblName.AutoSize = true;

            txtStudentName.Location = new Point(150, 67);
            txtStudentName.Width = 250;

            Label lblEmail = new Label();
            lblEmail.Text = "Email:";
            lblEmail.Location = new Point(30, 110);
            lblEmail.AutoSize = true;

            txtStudentEmail.Location = new Point(150, 107);
            txtStudentEmail.Width = 250;

            Label lblProgramme = new Label();
            lblProgramme.Text = "Programme:";
            lblProgramme.Location = new Point(30, 150);
            lblProgramme.AutoSize = true;

            txtProgramme.Location = new Point(150, 147);
            txtProgramme.Width = 250;

            Label lblYear = new Label();
            lblYear.Text = "Year:";
            lblYear.Location = new Point(30, 190);
            lblYear.AutoSize = true;

            numYear.Location = new Point(150, 187);
            numYear.Minimum = 1;
            numYear.Maximum = 10;
            numYear.Value = 1;

            // Buttons

            Button btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new Point(450, 27);
            btnAdd.Width = 100;
            btnAdd.Click += AddStudent;

            Button btnUpdate = new Button();
            btnUpdate.Text = "Update";
            btnUpdate.Location = new Point(560, 27);
            btnUpdate.Width = 100;
            btnUpdate.Click += UpdateStudent;

            Button btnDelete = new Button();
            btnDelete.Text = "Delete";
            btnDelete.Location = new Point(670, 27);
            btnDelete.Width = 100;
            btnDelete.Click += DeleteStudent;

            Button btnClear = new Button();
            btnClear.Text = "Clear";
            btnClear.Location = new Point(780, 27);
            btnClear.Width = 100;
            btnClear.Click += ClearStudentFields;

            // Student Grid

            studentGrid.Location = new Point(30, 250);
            studentGrid.Size = new Size(1000, 330);

            studentGrid.ReadOnly = true;
            studentGrid.AllowUserToAddRows = false;
            studentGrid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            studentGrid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            studentGrid.CellClick += StudentGrid_CellClick;

            tab.Controls.Add(lblStudentId);
            tab.Controls.Add(txtStudentId);

            tab.Controls.Add(lblName);
            tab.Controls.Add(txtStudentName);

            tab.Controls.Add(lblEmail);
            tab.Controls.Add(txtStudentEmail);

            tab.Controls.Add(lblProgramme);
            tab.Controls.Add(txtProgramme);

            tab.Controls.Add(lblYear);
            tab.Controls.Add(numYear);

            tab.Controls.Add(btnAdd);
            tab.Controls.Add(btnUpdate);
            tab.Controls.Add(btnDelete);
            tab.Controls.Add(btnClear);

            tab.Controls.Add(studentGrid);
        }

        // =========================================================
        // COURSE INTERFACE
        // =========================================================

        private void CreateCourseInterface(TabPage tab)
        {
            Label lblCourseCode = new Label();

            lblCourseCode.Text = "Course Code:";
            lblCourseCode.Location = new Point(30, 30);
            lblCourseCode.AutoSize = true;

            txtCourseCode.Location = new Point(150, 27);
            txtCourseCode.Width = 250;


            Label lblCourseName = new Label();

            lblCourseName.Text = "Course Name:";
            lblCourseName.Location = new Point(30, 70);
            lblCourseName.AutoSize = true;

            txtCourseName.Location = new Point(150, 67);
            txtCourseName.Width = 250;


            Label lblCreditHours = new Label();

            lblCreditHours.Text = "Credit Hours:";
            lblCreditHours.Location = new Point(30, 110);
            lblCreditHours.AutoSize = true;

            numCreditHours.Location = new Point(150, 107);

            numCreditHours.Minimum = 1;
            numCreditHours.Maximum = 10;
            numCreditHours.Value = 3;


            // Buttons

            Button btnAdd = new Button();

            btnAdd.Text = "Add";
            btnAdd.Location = new Point(450, 27);
            btnAdd.Width = 100;

            btnAdd.Click += AddCourse;


            Button btnUpdate = new Button();

            btnUpdate.Text = "Update";
            btnUpdate.Location = new Point(560, 27);
            btnUpdate.Width = 100;

            btnUpdate.Click += UpdateCourse;


            Button btnDelete = new Button();

            btnDelete.Text = "Delete";
            btnDelete.Location = new Point(670, 27);
            btnDelete.Width = 100;

            btnDelete.Click += DeleteCourse;


            Button btnClear = new Button();

            btnClear.Text = "Clear";
            btnClear.Location = new Point(780, 27);
            btnClear.Width = 100;

            btnClear.Click += ClearCourseFields;


            // Course Grid

            courseGrid.Location = new Point(30, 170);

            courseGrid.Size = new Size(1000, 400);

            courseGrid.ReadOnly = true;

            courseGrid.AllowUserToAddRows = false;

            courseGrid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            courseGrid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            courseGrid.CellClick += CourseGrid_CellClick;


            tab.Controls.Add(lblCourseCode);
            tab.Controls.Add(txtCourseCode);

            tab.Controls.Add(lblCourseName);
            tab.Controls.Add(txtCourseName);

            tab.Controls.Add(lblCreditHours);
            tab.Controls.Add(numCreditHours);

            tab.Controls.Add(btnAdd);
            tab.Controls.Add(btnUpdate);
            tab.Controls.Add(btnDelete);
            tab.Controls.Add(btnClear);

            tab.Controls.Add(courseGrid);
        }

        // =========================================================
        // STUDENT - LOAD
        // =========================================================

        private void LoadStudents()
        {
            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql =
                    "SELECT * FROM Students ORDER BY Id DESC";

                using var command =
                    new SqliteCommand(sql, connection);

                using var reader =
                    command.ExecuteReader();

                studentGrid.Rows.Clear();
                studentGrid.Columns.Clear();

                studentGrid.Columns.Add("Id", "ID");
                studentGrid.Columns.Add("StudentId", "Student ID");
                studentGrid.Columns.Add("Name", "Name");
                studentGrid.Columns.Add("Email", "Email");
                studentGrid.Columns.Add("Programme", "Programme");
                studentGrid.Columns.Add("Year", "Year");

                while (reader.Read())
                {
                    studentGrid.Rows.Add(
                        reader["Id"],
                        reader["StudentId"],
                        reader["Name"],
                        reader["Email"],
                        reader["Programme"],
                        reader["Year"]
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error loading students:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // STUDENT - ADD
        // =========================================================

        private void AddStudent(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStudentId.Text) ||
                string.IsNullOrWhiteSpace(txtStudentName.Text) ||
                string.IsNullOrWhiteSpace(txtStudentEmail.Text) ||
                string.IsNullOrWhiteSpace(txtProgramme.Text))
            {
                MessageBox.Show(
                    "Please fill in all student fields."
                );

                return;
            }

            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql = @"
                    INSERT INTO Students
                    (StudentId, Name, Email, Programme, Year)
                    VALUES
                    ($studentId, $name, $email, $programme, $year)
                ";

                using var command =
                    new SqliteCommand(sql, connection);

                command.Parameters.AddWithValue(
                    "$studentId",
                    txtStudentId.Text
                );

                command.Parameters.AddWithValue(
                    "$name",
                    txtStudentName.Text
                );

                command.Parameters.AddWithValue(
                    "$email",
                    txtStudentEmail.Text
                );

                command.Parameters.AddWithValue(
                    "$programme",
                    txtProgramme.Text
                );

                command.Parameters.AddWithValue(
                    "$year",
                    (int)numYear.Value
                );

                command.ExecuteNonQuery();

                MessageBox.Show("Student added successfully.");

                ClearStudentFields(null, null);

                LoadStudents();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error adding student:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // STUDENT - UPDATE
        // =========================================================

        private void UpdateStudent(object? sender, EventArgs e)
        {
            if (selectedStudentId == -1)
            {
                MessageBox.Show(
                    "Please select a student first."
                );

                return;
            }

            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql = @"
                    UPDATE Students
                    SET
                        StudentId = $studentId,
                        Name = $name,
                        Email = $email,
                        Programme = $programme,
                        Year = $year
                    WHERE Id = $id
                ";

                using var command =
                    new SqliteCommand(sql, connection);

                command.Parameters.AddWithValue(
                    "$studentId",
                    txtStudentId.Text
                );

                command.Parameters.AddWithValue(
                    "$name",
                    txtStudentName.Text
                );

                command.Parameters.AddWithValue(
                    "$email",
                    txtStudentEmail.Text
                );

                command.Parameters.AddWithValue(
                    "$programme",
                    txtProgramme.Text
                );

                command.Parameters.AddWithValue(
                    "$year",
                    (int)numYear.Value
                );

                command.Parameters.AddWithValue(
                    "$id",
                    selectedStudentId
                );

                command.ExecuteNonQuery();

                MessageBox.Show("Student updated successfully.");

                ClearStudentFields(null, null);

                LoadStudents();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error updating student:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // STUDENT - DELETE
        // =========================================================

        private void DeleteStudent(object? sender, EventArgs e)
        {
            if (selectedStudentId == -1)
            {
                MessageBox.Show(
                    "Please select a student first."
                );

                return;
            }

            DialogResult result =
                MessageBox.Show(
                    "Are you sure you want to delete this student?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

            if (result != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql =
                    "DELETE FROM Students WHERE Id = $id";

                using var command =
                    new SqliteCommand(sql, connection);

                command.Parameters.AddWithValue(
                    "$id",
                    selectedStudentId
                );

                command.ExecuteNonQuery();

                MessageBox.Show("Student deleted successfully.");

                ClearStudentFields(null, null);

                LoadStudents();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error deleting student:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // STUDENT - SELECT
        // =========================================================

        private void StudentGrid_CellClick(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row =
                studentGrid.Rows[e.RowIndex];

            selectedStudentId =
                Convert.ToInt32(row.Cells["Id"].Value);

            txtStudentId.Text =
                row.Cells["StudentId"].Value?.ToString();

            txtStudentName.Text =
                row.Cells["Name"].Value?.ToString();

            txtStudentEmail.Text =
                row.Cells["Email"].Value?.ToString();

            txtProgramme.Text =
                row.Cells["Programme"].Value?.ToString();

            numYear.Value =
                Convert.ToDecimal(row.Cells["Year"].Value);
        }

        // =========================================================
        // STUDENT - CLEAR
        // =========================================================

        private void ClearStudentFields(
            object? sender,
            EventArgs? e)
        {
            selectedStudentId = -1;

            txtStudentId.Clear();
            txtStudentName.Clear();
            txtStudentEmail.Clear();
            txtProgramme.Clear();

            numYear.Value = 1;

            studentGrid.ClearSelection();
        }

        // =========================================================
        // COURSE - LOAD
        // =========================================================

        private void LoadCourses()
        {
            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql =
                    "SELECT * FROM Courses ORDER BY Id DESC";

                using var command =
                    new SqliteCommand(sql, connection);

                using var reader =
                    command.ExecuteReader();

                courseGrid.Rows.Clear();
                courseGrid.Columns.Clear();

                courseGrid.Columns.Add("Id", "ID");
                courseGrid.Columns.Add(
                    "CourseCode",
                    "Course Code"
                );

                courseGrid.Columns.Add(
                    "CourseName",
                    "Course Name"
                );

                courseGrid.Columns.Add(
                    "CreditHours",
                    "Credit Hours"
                );

                while (reader.Read())
                {
                    courseGrid.Rows.Add(
                        reader["Id"],
                        reader["CourseCode"],
                        reader["CourseName"],
                        reader["CreditHours"]
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error loading courses:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // COURSE - ADD
        // =========================================================

        private void AddCourse(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCourseCode.Text) ||
                string.IsNullOrWhiteSpace(txtCourseName.Text))
            {
                MessageBox.Show(
                    "Please fill in all course fields."
                );

                return;
            }

            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql = @"
                    INSERT INTO Courses
                    (CourseCode, CourseName, CreditHours)
                    VALUES
                    ($courseCode, $courseName, $creditHours)
                ";

                using var command =
                    new SqliteCommand(sql, connection);

                command.Parameters.AddWithValue(
                    "$courseCode",
                    txtCourseCode.Text
                );

                command.Parameters.AddWithValue(
                    "$courseName",
                    txtCourseName.Text
                );

                command.Parameters.AddWithValue(
                    "$creditHours",
                    (int)numCreditHours.Value
                );

                command.ExecuteNonQuery();

                MessageBox.Show("Course added successfully.");

                ClearCourseFields(null, null);

                LoadCourses();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error adding course:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // COURSE - UPDATE
        // =========================================================

        private void UpdateCourse(object? sender, EventArgs e)
        {
            if (selectedCourseId == -1)
            {
                MessageBox.Show(
                    "Please select a course first."
                );

                return;
            }

            if (string.IsNullOrWhiteSpace(txtCourseCode.Text) ||
                string.IsNullOrWhiteSpace(txtCourseName.Text))
            {
                MessageBox.Show(
                    "Please fill in all course fields."
                );

                return;
            }

            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql = @"
                    UPDATE Courses
                    SET
                        CourseCode = $courseCode,
                        CourseName = $courseName,
                        CreditHours = $creditHours
                    WHERE Id = $id
                ";

                using var command =
                    new SqliteCommand(sql, connection);

                command.Parameters.AddWithValue(
                    "$courseCode",
                    txtCourseCode.Text
                );

                command.Parameters.AddWithValue(
                    "$courseName",
                    txtCourseName.Text
                );

                command.Parameters.AddWithValue(
                    "$creditHours",
                    (int)numCreditHours.Value
                );

                command.Parameters.AddWithValue(
                    "$id",
                    selectedCourseId
                );

                command.ExecuteNonQuery();

                MessageBox.Show("Course updated successfully.");

                ClearCourseFields(null, null);

                LoadCourses();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error updating course:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // COURSE - DELETE
        // =========================================================

        private void DeleteCourse(object? sender, EventArgs e)
        {
            if (selectedCourseId == -1)
            {
                MessageBox.Show(
                    "Please select a course first."
                );

                return;
            }

            DialogResult result =
                MessageBox.Show(
                    "Are you sure you want to delete this course?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

            if (result != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using var connection =
                    Data.Database.GetConnection();

                connection.Open();

                string sql =
                    "DELETE FROM Courses WHERE Id = $id";

                using var command =
                    new SqliteCommand(sql, connection);

                command.Parameters.AddWithValue(
                    "$id",
                    selectedCourseId
                );

                command.ExecuteNonQuery();

                MessageBox.Show("Course deleted successfully.");

                ClearCourseFields(null, null);

                LoadCourses();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error deleting course:\n" + ex.Message
                );
            }
        }

        // =========================================================
        // COURSE - SELECT
        // =========================================================

        private void CourseGrid_CellClick(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row =
                courseGrid.Rows[e.RowIndex];

            selectedCourseId =
                Convert.ToInt32(row.Cells["Id"].Value);

            txtCourseCode.Text =
                row.Cells["CourseCode"].Value?.ToString();

            txtCourseName.Text =
                row.Cells["CourseName"].Value?.ToString();

            numCreditHours.Value =
                Convert.ToDecimal(
                    row.Cells["CreditHours"].Value
                );
        }

        // =========================================================
        // COURSE - CLEAR
        // =========================================================

        private void ClearCourseFields(
            object? sender,
            EventArgs? e)
        {
            selectedCourseId = -1;

            txtCourseCode.Clear();
            txtCourseName.Clear();

            numCreditHours.Value = 3;

            courseGrid.ClearSelection();
        }
    }
}