using Microsoft.Data.Sqlite;

namespace StudentCourseManagementSystem.Data
{
	public static class Database
	{
		private const string ConnectionString = "Data Source=students.db";

		public static SqliteConnection GetConnection()
		{
			return new SqliteConnection(ConnectionString);
		}

		public static void Initialize()
		{
			using var connection = GetConnection();

			connection.Open();

			string studentTable = @"
                CREATE TABLE IF NOT EXISTS Students
                (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    StudentId TEXT NOT NULL,
                    Name TEXT NOT NULL,
                    Email TEXT NOT NULL,
                    Programme TEXT NOT NULL,
                    Year INTEGER NOT NULL
                )";

			string courseTable = @"
                CREATE TABLE IF NOT EXISTS Courses
                (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    CourseCode TEXT NOT NULL,
                    CourseName TEXT NOT NULL,
                    CreditHours INTEGER NOT NULL
                )";

			using var studentCommand =
				new SqliteCommand(studentTable, connection);

			studentCommand.ExecuteNonQuery();

			using var courseCommand =
				new SqliteCommand(courseTable, connection);

			courseCommand.ExecuteNonQuery();
		}
	}
}